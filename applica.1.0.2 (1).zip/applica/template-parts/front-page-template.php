<?php
/*
Template Name: Homepage Template
*/
get_header();
?>

<?php if ( is_active_sidebar( 'fullwidth-front-page-widgetarea' ) ) : ?>

<div class="" role="complementary">
    <?php dynamic_sidebar( 'fullwidth-front-page-widgetarea' ); ?>
</div>

<?php endif; ?>

<?php get_footer();