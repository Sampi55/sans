<?php

/**
 * This file will display our icon set on request
 *
 * @package Applica
 */

get_header(); ?>

<div class="theme-icon-lists">
    <div class="wrapper">
        <div class="column-row">
            <div class="column column-12">
                <table style="width:100%">
                    <thead>
                        <tr>
                            <th> icon name </th>
                            <th> icon </th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td>
                                menu
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('menu'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                plus
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('plus'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                minus
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('minus'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                arrow-down
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('arrow-down'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                arrow-left
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('arrow-left'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                arrow-right
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('arrow-right'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                arrow-up
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('arrow-up'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                chevron-down
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('chevron-down'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                chevron-up
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('chevron-up'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                chevron-left
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('chevron-left'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                chevron-right
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('chevron-right'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                blaze
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('blaze'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                bookmark
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('bookmark'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                calendar
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('calendar'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                clock
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('clock'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                calendar-full
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('calendar-full'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                viewer
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('viewer'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                comment
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('comment'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                cross
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('cross'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                edit
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('edit'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                folder
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('folder'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                fullscreen
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('fullscreen'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                search
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('search'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                tag
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('tag'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                user
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('user'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                recent
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('recent'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                star
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('star'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                latest
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('latest'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                close
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('close'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                play
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('play'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                pause
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('pause'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                moon
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('moon'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                sun
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('sun'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                audio
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('audio'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                gallery
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('gallery'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                image
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('image'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                video
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('video'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                quote
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('quote'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                amazon
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('amazon'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                apple
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('apple'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                bandcamp
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('bandcamp'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                behance
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('behance'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                chain
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('chain'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                codepen
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('codepen'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                deviantart
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('deviantart'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                digg
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('digg'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                dribbble
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('dribbble'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                dropbox
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('dropbox'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                etsy
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('etsy'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                facebook
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('facebook'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                feed
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('feed'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                flickr
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('flickr'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                foursquare
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('foursquare'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                goodreads
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('goodreads'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                github
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('github'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                instagram
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('instagram'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                lastfm
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('lastfm'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                linkedin
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('linkedin'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                mail
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('mail'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                meetup
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('meetup'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                medium
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('medium'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                pinterest
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('pinterest'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                pocket
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('pocket'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                reddit
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('reddit'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                skype
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('skype'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                slideshare
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('slideshare'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                snapchat
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('snapchat'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                soundcloud
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('soundcloud'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                spotify
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('spotify'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                stumbleupon
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('stumbleupon'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                tumblr
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('tumblr'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                twitch
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('twitch'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                twitter
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('twitter'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                vimeo
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('vimeo'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                vk
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('vk'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                wp
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('wp'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                yelp
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('yelp'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                youtube
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('youtube'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                whatsapp
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('whatsapp'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                tiktok
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('tiktok'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                email
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('email'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                phone
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('phone'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                finance
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('finance'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                pie-chart
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('pie-chart'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                web
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('web'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                delivery
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('delivery'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                team
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('team'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                plane
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('plane'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                idea
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('idea'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                target
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('target'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                setting
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('setting'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                parcel
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('parcel'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                progress
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('progress'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                equalizer
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('equalizer'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                wallet
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('wallet'); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                location
                            </td>
                            <td>
                                <span>
                                    <?php applica_theme_svg('location'); ?>
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
