<?php
/*Header Options*/
$wp_customize->add_section(
    'general_settings' ,
    array(
        'title' => __( 'General Settings', 'applica' ),
        'panel' => 'applica_option_panel',
    )
);

/*Show Preloader*/
$wp_customize->add_setting(
    'applica_options[show_lightbox_image]',
    array(
        'default'           => $default_options['show_lightbox_image'],
        'sanitize_callback' => 'applica_sanitize_checkbox',
    )
);
$wp_customize->add_control(
    'applica_options[show_lightbox_image]',
    array(
        'label'    => __( 'Show LightBox Image', 'applica' ),
        'section'  => 'general_settings',
        'type'     => 'checkbox',
    )
);
