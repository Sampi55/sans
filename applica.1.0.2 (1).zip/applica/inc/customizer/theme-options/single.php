<?php

$wp_customize->add_section(
    'single_options' ,
    array(
        'title' => __( 'Single Options', 'applica' ),
        'panel' => 'applica_option_panel',
    )
);

/* Global Layout*/
$wp_customize->add_setting(
    'applica_options[single_sidebar_layout]',
    array(
        'default'           => $default_options['single_sidebar_layout'],
        'sanitize_callback' => 'applica_sanitize_radio',
    )
);
$wp_customize->add_control(
    new Applica_Radio_Image_Control(
        $wp_customize,
        'applica_options[single_sidebar_layout]',
        array(
            'label' => __( 'Single Sidebar Layout', 'applica' ),
            'section' => 'single_options',
            'choices' => applica_get_general_layouts()
        )
    )
);

// Hide Side Bar on Mobile
$wp_customize->add_setting(
    'applica_options[hide_single_sidebar_mobile]',
    array(
        'default'           => $default_options['hide_single_sidebar_mobile'],
        'sanitize_callback' => 'applica_sanitize_checkbox',
    )
);
$wp_customize->add_control(
    'applica_options[hide_single_sidebar_mobile]',
    array(
        'label'       => __( 'Hide Single Sidebar on Mobile', 'applica' ),
        'section'     => 'single_options',
        'type'        => 'checkbox',
    )
);

$wp_customize->add_setting(
    'applica_section_seperator_single_1',
    array(
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    new Applica_Seperator_Control(
        $wp_customize,
        'applica_section_seperator_single_1',
        array(
            'settings' => 'applica_section_seperator_single_1',
            'section'       => 'single_options',
        )
    )
);

/* Post Meta */
$wp_customize->add_setting(
    'applica_options[single_post_meta]',
    array(
        'default'           => $default_options['single_post_meta'],
        'sanitize_callback' => 'applica_sanitize_checkbox_multiple',
    )
);
$wp_customize->add_control(
    new Applica_Checkbox_Multiple(
        $wp_customize,
        'applica_options[single_post_meta]',
        array(
            'label' => __( 'Single Post Meta', 'applica' ),
            'description'   => __( 'Choose the post meta you want to be displayed on post detail page', 'applica' ),
            'section' => 'single_options',
            'choices' => array(
                'author' => __( 'Author', 'applica' ),
                'date' => __( 'Date', 'applica' ),
                'comment' => __( 'Comment', 'applica' ),
                'category' => __( 'Category', 'applica' ),
                'tags' => __( 'Tags', 'applica' ),
            )
        )
    )
);


$wp_customize->add_setting(
    'applica_section_seperator_single_2',
    array(
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    new Applica_Seperator_Control( 
        $wp_customize,
        'applica_section_seperator_single_2',
        array(
            'settings' => 'applica_section_seperator_single_2',
            'section'       => 'single_options',
        )
    )
);

/*Show Author Info Box
*-------------------------------*/
$wp_customize->add_setting(
    'applica_options[show_author_info]',
    array(
        'default'           => $default_options['show_author_info'],
        'sanitize_callback' => 'applica_sanitize_checkbox',
    )
);
$wp_customize->add_control(
    'applica_options[show_author_info]',
    array(
        'label'    => __( 'Show Author Info Box', 'applica' ),
        'section'  => 'single_options',
        'type'     => 'checkbox',
    )
);

$wp_customize->add_setting(
    'applica_section_seperator_single_3',
    array(
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    new Applica_Seperator_Control(
        $wp_customize,
        'applica_section_seperator_single_3',
        array(
            'settings' => 'applica_section_seperator_single_3',
            'section'       => 'single_options',
        )
    )
);

/*Show Related Posts
*-------------------------------*/
$wp_customize->add_setting(
    'applica_options[show_related_posts]',
    array(
        'default'           => $default_options['show_related_posts'],
        'sanitize_callback' => 'applica_sanitize_checkbox',
    )
);
$wp_customize->add_control(
    'applica_options[show_related_posts]',
    array(
        'label'    => __( 'Show Related Posts', 'applica' ),
        'section'  => 'single_options',
        'type'     => 'checkbox',
    )
);

/*Related Posts Text.*/
$wp_customize->add_setting(
    'applica_options[related_posts_text]',
    array(
        'default'           => $default_options['related_posts_text'],
        'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control(
    'applica_options[related_posts_text]',
    array(
        'label'    => __( 'Related Posts Text', 'applica' ),
        'section'  => 'single_options',
        'type'     => 'text',
        'active_callback' => 'applica_is_related_posts_enabled',
    )
);

/* Number of Related Posts */
$wp_customize->add_setting(
    'applica_options[no_of_related_posts]',
    array(
        'default'           => $default_options['no_of_related_posts'],
        'sanitize_callback' => 'absint',
    )
);
$wp_customize->add_control(
    'applica_options[no_of_related_posts]',
    array(
        'label'       => __( 'Number of Related Posts', 'applica' ),
        'section'     => 'single_options',
        'type'        => 'number',
        'active_callback' => 'applica_is_related_posts_enabled',
    )
);

/*Related Posts Orderby*/
$wp_customize->add_setting(
    'applica_options[related_posts_orderby]',
    array(
        'default'           => $default_options['related_posts_orderby'],
        'sanitize_callback' => 'applica_sanitize_select',
    )
);
$wp_customize->add_control(
    'applica_options[related_posts_orderby]',
    array(
        'label'       => __( 'Orderby', 'applica' ),
        'section'     => 'single_options',
        'type'        => 'select',
        'choices' => array(
            'date' => __('Date', 'applica'),
            'id' => __('ID', 'applica'),
            'title' => __('Title', 'applica'),
            'rand' => __('Random', 'applica'),
        ),
        'active_callback' => 'applica_is_related_posts_enabled',
    )
);

/*Related Posts Order*/
$wp_customize->add_setting(
    'applica_options[related_posts_order]',
    array(
        'default'           => $default_options['related_posts_order'],
        'sanitize_callback' => 'applica_sanitize_select',
    )
);
$wp_customize->add_control(
    'applica_options[related_posts_order]',
    array(
        'label'       => __( 'Order', 'applica' ),
        'section'     => 'single_options',
        'type'        => 'select',
        'choices' => array(
            'asc' => __('ASC', 'applica'),
            'desc' => __('DESC', 'applica'),
        ),
        'active_callback' => 'applica_is_related_posts_enabled',
    )
);

$wp_customize->add_setting(
    'applica_section_seperator_single_4',
    array(
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    new Applica_Seperator_Control(
        $wp_customize,
        'applica_section_seperator_single_4',
        array(
            'settings' => 'applica_section_seperator_single_4',
            'section'       => 'single_options',
        )
    )
);
/*Show Author Posts
*-----------------------------------------*/
$wp_customize->add_setting(
    'applica_options[show_author_posts]',
    array(
        'default'           => $default_options['show_author_posts'],
        'sanitize_callback' => 'applica_sanitize_checkbox',
    )
);
$wp_customize->add_control(
    'applica_options[show_author_posts]',
    array(
        'label'    => __( 'Show Author Posts', 'applica' ),
        'section'  => 'single_options',
        'type'     => 'checkbox',
    )
);

/*Author Posts Text.*/
$wp_customize->add_setting(
    'applica_options[author_posts_text]',
    array(
        'default'           => $default_options['author_posts_text'],
        'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control(
    'applica_options[author_posts_text]',
    array(
        'label'    => __( 'Author Posts Text', 'applica' ),
        'section'  => 'single_options',
        'type'     => 'text',
        'active_callback' => 'applica_is_author_posts_enabled',
    )
);

/* Number of Author Posts */
$wp_customize->add_setting(
    'applica_options[no_of_author_posts]',
    array(
        'default'           => $default_options['no_of_author_posts'],
        'sanitize_callback' => 'absint',
    )
);
$wp_customize->add_control(
    'applica_options[no_of_author_posts]',
    array(
        'label'       => __( 'Number of Author Posts', 'applica' ),
        'section'     => 'single_options',
        'type'        => 'number',
        'active_callback' => 'applica_is_author_posts_enabled',
    )
);

/*Author Posts Orderby*/
$wp_customize->add_setting(
    'applica_options[author_posts_orderby]',
    array(
        'default'           => $default_options['author_posts_orderby'],
        'sanitize_callback' => 'applica_sanitize_select',
    )
);
$wp_customize->add_control(
    'applica_options[author_posts_orderby]',
    array(
        'label'       => __( 'Orderby', 'applica' ),
        'section'     => 'single_options',
        'type'        => 'select',
        'choices' => array(
            'date' => __('Date', 'applica'),
            'id' => __('ID', 'applica'),
            'title' => __('Title', 'applica'),
            'rand' => __('Random', 'applica'),
        ),
        'active_callback' => 'applica_is_author_posts_enabled',
    )
);

/*Author Posts Order*/
$wp_customize->add_setting(
    'applica_options[author_posts_order]',
    array(
        'default'           => $default_options['author_posts_order'],
        'sanitize_callback' => 'applica_sanitize_select',
    )
);
$wp_customize->add_control(
    'applica_options[author_posts_order]',
    array(
        'label'       => __( 'Order', 'applica' ),
        'section'     => 'single_options',
        'type'        => 'select',
        'choices' => array(
            'asc' => __('ASC', 'applica'),
            'desc' => __('DESC', 'applica'),
        ),
        'active_callback' => 'applica_is_author_posts_enabled',
    )
);