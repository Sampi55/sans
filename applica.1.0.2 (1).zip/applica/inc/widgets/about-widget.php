<?php
if (!defined('ABSPATH')) {
    exit;
}

class Applica_About_Widget extends Applica_Widget_Base
{
    /**
     * Sets up a new widget instance.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
       
        $this->widget_cssclass = 'widget_applica_about_posts';
        $this->widget_description = __("Displays about posts with an image", 'applica');
        $this->widget_id = 'applica_about_posts';
        $this->widget_name = __('Applica: Aboout Section', 'applica');
        $this->settings = array(
            'select_about_page' => array(
                'label' => esc_html__('Select About Page', 'applica'),
                'type' => 'dropdown-pages',
                'std' => '',
            ),
            'flip_image' => array(
                'type' => 'checkbox',
                'label' => __('Flip Image $ Content', 'applica'),
                'std' => true,
            ),
            'button_text' => array(
                'type' => 'text',
                'label' => __('Button Text', 'applica'),
            ),
            'button_url' => array(
                'type' => 'url',
                'label' => __('Button URL', 'applica'),
            ),

        );
        parent::__construct();
    }

    /**
     * Query the posts and return them.
     * @param array $args
     * @param array $instance
     * @return WP_Query
     */
    public function get_posts($args, $instance)
    {
        $query_args = array(
            'posts_per_page' => 1,
            'orderby' => 'post__in',
            'post_type' => 'page',
            'page_id' => $instance['select_about_page'],
        );

        return new WP_Query(apply_filters('applica_about_posts_query_args', $query_args));
    }

    /**
     * Output widget.
     *
     * @param array $args
     * @param array $instance
     * @see WP_Widget
     *
     */
    public function widget($args, $instance)
    {
        ob_start();
        $flip_class = "";
        if (!empty($instance['flip_image'])) {
            $flip_class = "split-layout-flip";
        }

            ?>
            <section class="theme-article-flex theme-block">
                <div class="wrapper">
                    <div class="column-row">
                        <div class="column column-12">
                        <?php if (($posts = $this->get_posts($args, $instance)) && $posts->have_posts()) {
                            while ($posts->have_posts()): $posts->the_post(); 
                                    $featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
                                    $featured_image = isset($featured_image[0]) ? $featured_image[0] : '';
                                ?>
                            <article class="theme-news-article article-split-layout <?php echo esc_attr($flip_class); ?>">
                                <div class="theme-applica-image image-size-big">
                                    <img src="<?php echo esc_url($featured_image); ?>" alt="">
                                </div>

                                <div class="theme-applica-content bg-color-cultured">
                                    <h2 class="entry-title font-size-big mb-16 line-clamp line-clamp-2">
                                        <a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a>
                                    </h2>

                                    <div class="article-excerpt line-clamp line-clamp-4 mb-16">
                                        <p><?php the_excerpt(); ?>
                                        </p>
                                    </div>

                                        <a href="<?php echo esc_url($instance['button_url']); ?>" class='theme-button'> <?php echo esc_html($instance['button_text']); ?>  </a>
                                </div>
                            </article>
                            <?php endwhile;
                            wp_reset_postdata();  
                        }?>
                        </div>
                    </div>
                </div>
            </section>
            <?php
        echo ob_get_clean();
    }
}
