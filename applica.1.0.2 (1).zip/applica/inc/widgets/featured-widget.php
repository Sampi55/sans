<?php
if (!defined('ABSPATH')) {
    exit;
}

class Applica_Featured_Widget extends Applica_Widget_Base
{
    /**
     * Sets up a new widget instance.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        $this->widget_cssclass = 'widget_applica_featured_posts';
        $this->widget_description = __("Displays featured section with an image", 'applica');
        $this->widget_id = 'applica_featured_posts';
        $this->widget_name = __('Applica: Featured Section', 'applica');
        $this->settings = array(
            'title' => array(
                'type' => 'text',
                'label' => __('Title', 'applica'),
            ),
            'description' => array(
                'type' => 'textarea',
                'label' => __('Section Description', 'applica'),
            ),
            'featured_image'  => array(
                'type'  => 'image',
                'label' => __('Featured Image', 'applica'),
            ),
            'button_text' => array(
                'type' => 'text',
                'label' => __('Button Text', 'applica'),
            ),
            'button_url' => array(
                'type' => 'url',
                'label' => __('Button URL', 'applica'),
            ),

            'button_text_2' => array(
                'type' => 'text',
                'label' => __('Button Text -2', 'applica'),
            ),
            'button_url_2' => array(
                'type' => 'url',
                'label' => __('Button URL-2', 'applica'),
            ),

        );
        parent::__construct();
    }

    /**
     * Output widget.
     *
     * @param array $args
     * @param array $instance
     * @see WP_Widget
     *
     */
    public function widget($args, $instance)
    {
        ob_start();
            ?>
            <section class="theme-hero theme-block text-white">
                <div class="theme-hero-content">
                    <div class="wrapper">
                      <div class="column-row column-row-center">
                          <div class="column column-6 column-xs-12 xs-mb-24">
                            <h2 class="entry-title font-size-large">
                              <?php echo esc_html($instance['title']); ?>
                            </h2>

                            <p>
                              <?php echo esc_html($instance['description']); ?> 
                            </p>

                            <div class="theme-btn-group">
                                 <a href="<?php echo esc_html($instance['button_url']); ?>" class='theme-button'> <?php echo esc_html($instance['button_text']); ?> </a>
                                <a href="<?php echo esc_html($instance['button_url_2']); ?>" class='theme-button'> <?php echo esc_html($instance['button_text_2']); ?> </a>
                            </div>
                          </div>

                          <div class="column column-6 column-xs-12">
                            <div class="theme-applica-image image-size-large">
                                <img src="<?php echo esc_url(wp_get_attachment_image_url( $instance['featured_image'], 'medium-large' )); ?>" alt="">
                            </div>
                          </div>
                      </div>
                    </div>
                </div>
            </section>
            <?php
        echo ob_get_clean();
    }
}