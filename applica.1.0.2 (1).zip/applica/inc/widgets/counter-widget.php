<?php
if (!defined('ABSPATH')) {
    exit;
}

class Applica_Counter_Widget extends Applica_Widget_Base
{
    /**
     * Sets up a new widget instance.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
         $icon_page_link = get_site_url() . '/twp-applica-svg-icon-set';
        $this->widget_cssclass = 'widget_applica_counter_posts';
        $this->widget_description = __("Displays counter section with an image", 'applica');
        $this->widget_id = 'applica_counter_posts';
        $this->widget_name = __('Applica: Counter Section', 'applica');
        $this->settings = array(
            'title' => array(
                'type' => 'text',
                'label' => __('Title', 'applica'),
            ),
            'description' => array(
                'type' => 'textarea',
                'label' => __('Section Description', 'applica'),
            ),
            'counter_image'  => array(
                'type'  => 'image',
                'label' => __('Counter Image', 'applica'),
            ),
            'counter_icon_1' => array(
                'type' => 'text',
                'label' => __('Counter Icon - 1', 'applica'),
                'desc' => sprintf(__('For SVG Icon  <a href="%s" target="_blank">Click Here</a> to see inbuild icon set', 'applica'), $icon_page_link),
            ),
            'counter_title_1' => array(
                'type' => 'textarea',
                'label' => __('Counter Title - 1', 'applica'),
            ),
            'counter_number_1' => array(
                'type' => 'textarea',
                'label' => __('Counter Number - 1', 'applica'),
            ),
            'counter_icon_2' => array(
                'type' => 'text',
                'label' => __('Counter Icon - 2', 'applica'),
                'desc' => sprintf(__('For SVG Icon  <a href="%s" target="_blank">Click Here</a> to see inbuild icon set', 'applica'), $icon_page_link),
            ),
            'counter_title_2' => array(
                'type' => 'textarea',
                'label' => __('Counter Title - 2', 'applica'),
            ),
            'counter_number_2' => array(
                'type' => 'textarea',
                'label' => __('Counter Number - 2', 'applica'),
            ),
            'counter_icon_3' => array(
                'type' => 'text',
                'label' => __('Counter Icon - 3', 'applica'),
                'desc' => sprintf(__('For SVG Icon  <a href="%s" target="_blank">Click Here</a> to see inbuild icon set', 'applica'), $icon_page_link),
            ),
            'counter_title_3' => array(
                'type' => 'textarea',
                'label' => __('Counter Title - 3', 'applica'),
            ),
            'counter_number_3' => array(
                'type' => 'textarea',
                'label' => __('Counter Number - 3', 'applica'),
            ),
            'counter_icon_4' => array(
                'type' => 'text',
                'label' => __('Counter Icon - 4', 'applica'),
                'desc' => sprintf(__('For SVG Icon  <a href="%s" target="_blank">Click Here</a> to see inbuild icon set', 'applica'), $icon_page_link),
            ),
            'counter_title_4' => array(
                'type' => 'textarea',
                'label' => __('Counter Title - 4', 'applica'),
            ),
            'counter_number_4' => array(
                'type' => 'textarea',
                'label' => __('Counter Number - 4', 'applica'),
            ),
        );
        parent::__construct();
    }

    /**
     * Output widget.
     *
     * @param array $args
     * @param array $instance
     * @see WP_Widget
     *
     */
    public function widget($args, $instance)
    {
        ob_start();
            ?>

            <section class="theme-cta-two theme-block">
                <div class="wrapper">
                    <div class="column-row">
                        <div class="column column-6 column-sm-12 sm-mb-16">
                            <div class="theme-applica-image image-size-big">
                                <img src="<?php echo esc_url(wp_get_attachment_image_url( $instance['counter_image'], 'medium-large' )); ?>" alt="">
                            </div>
                        </div>

                        <div class="column column-6 column-sm-12">
                            <h2 class="font-size-big mb-24">
                                <?php echo esc_html($instance['title']); ?>
                            </h2>

                            <p class="m-0 mb-24">
                                <?php echo esc_html($instance['description']); ?> 
                            </p>

                            <div class="cta-increasing-number">
                                <?php for ($i= 1; $i < 5; $i++) { 
                                    
                                 ?>
                                    <div class="increasing-number-item bg-color-cultured">
                                        <?php if (!empty($instance['counter_icon_' . $i])) { ?>
                                            <?php applica_theme_svg($instance['counter_icon_' . $i]); ?>
                                        <?php } ?>
                                        <div class="increasing-number-detail">
                                            <span class="increasing-number font-size-medium mb-4 purecounter" data-purecounter-start="0" 
                                            data-purecounter-end="<?php echo absint($instance['counter_number_' . $i]) ?>"
                                            data-purecounter-once="true"
                                            data-purecounter-seperator="true"><?php echo (0); ?></span>
                                            <span> <?php echo esc_html($instance['counter_title_' . $i]); ?> </span>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php
        echo ob_get_clean();
    }
}