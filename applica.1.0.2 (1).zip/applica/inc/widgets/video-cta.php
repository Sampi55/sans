<?php

if (!defined('ABSPATH')) {
    exit;
}

class Applica_Video_Call_To_Action extends Applica_Widget_Base
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->widget_cssclass = 'widget_applica_video_call_to_action';
        $this->widget_description = __("Adds Call to action section", 'applica');
        $this->widget_id = 'applica_video_call_to_action';
        $this->widget_name = __('Applica: Video Call To Action', 'applica');

        $this->settings = array(
            'title' => array(
                'type' => 'text',
                'label' => __('CTA Title', 'applica'),
            ),
            'title_text' => array(
                'type' => 'text',
                'label' => __('CTA Subtitle', 'applica'),
            ),
            'desc' => array(
                'type' => 'textarea',
                'label' => __('CTA Description', 'applica'),
                'rows' => 10,
            ),
            'bg_image' => array(
                'type' => 'image',
                'label' => __('Background Image', 'applica'),
            ),
            'video_link' => array(
                'type' => 'url',
                'label' => __('Link to video url', 'applica'),
                'desc' => __('Enter a proper url with http: OR https:', 'applica'),
            ),
            'msg' => array(
                'type' => 'message',
                'label' => __('Additonal Settings', 'applica'),
            ),
            'height' => array(
                'type' => 'number',
                'step' => 20,
                'min' => 300,
                'max' => 700,
                'std' => 400,
                'label' => __('Height: Between 300px and 700px (Default 400px)', 'applica'),
            ),
            'text_color_option' => array(
                'type' => 'color',
                'label' => __('Text Color', 'applica'),
                'std' => '#ffffff',
            ),
            'text_align' => array(
                'type' => 'select',
                'label' => __('Text Alignment', 'applica'),
                'options' => array(
                    'left' => __('Left Align', 'applica'),
                    'center' => __('Center Align', 'applica'),
                    'right' => __('Right Align', 'applica'),
                ),
                'std' => 'left',
            ),
            'enable_fixed_bg' => array(
                'type' => 'checkbox',
                'label' => __('Enable Fixed Background Image', 'applica'),
                'std' => true,
            ),
            'bg_overlay_color' => array(
                'type' => 'color',
                'label' => __('Overlay Background Color', 'applica'),
                'std' => '#000000',
            ),
            'overlay_opacity' => array(
                'type' => 'number',
                'step' => 10,
                'min' => 0,
                'max' => 100,
                'std' => 50,
                'label' => __('Overlay Opacity (Default 50%)', 'applica'),
            ),
        );

        parent::__construct();
    }

    /**
     * Output widget.
     *
     * @see WP_Widget
     *
     * @param array $args
     * @param array $instance
     */
    public function widget($args, $instance)
    {
        ob_start();
        echo $args['before_widget'];

        do_action('applica_before_video_cta');

        ?>

        <?php if ($instance['bg_image'] && 0 != $instance['bg_image']): ?>

            <?php
            $style_text = 'color:' . $instance['text_color_option'] . ';';
            $style_text .= 'min-height:' . $instance['height'] . 'px;';

            $style_text .= 'text-align:' . $instance['text_align'] . ';';

            $style = 'background-color:' . $instance['bg_overlay_color'] . ';';
            $style .= 'opacity:' . ($instance['overlay_opacity'] / 100) . ';';
            ?>

            <section class="theme-promotional-video applica-video_cta-widget applica-cover-block <?php echo ($instance['enable_fixed_bg']) ? 'applica-bg-image applica-bg-attachment-fixed' : ''; ?>"
                style="<?php echo esc_attr($style_text); ?>">

                <span aria-hidden="true" class="applica-block-overlay" style="<?php echo esc_attr($style); ?>"></span>

                <?php echo wp_get_attachment_image($instance['bg_image'], 'full'); ?>

                <div class="applica-video_cta-inner-wrapper applica-block-inner-wrapper">
                    <?php if ($instance['title']): ?>
                        <h2 class="entry-title font-size-big mb-8">
                            <?php echo esc_html($instance['title']); ?>
                        </h2>
                    <?php endif; ?>

                    <?php if ($instance['title_text']): ?>
                        <h3 class="entry-title font-size-medium m-0">
                            <?php echo esc_html($instance['title_text']); ?>
                        </h3>
                    <?php endif; ?>

                    <?php if ($instance['desc']): ?>
                        <div>
                            <?php echo wpautop(wp_kses_post($instance['desc'])); ?>
                        </div>
                    <?php endif; ?>

                    <button class="promotional-btn">
                        <?php applica_theme_svg('play'); ?>
                    </button>

                    <div class="promotional-video-modal">
                        <div class="video-modal-overlay"></div>
                        <div class="video-modal-content">
                            <iframe width="560" height="315" src="<?php echo esc_url($instance['video_link']) ?>" title="<?php echo esc_html($instance['title_text']); ?>" frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowfullscreen></iframe>
                            <?php applica_theme_svg('cross'); ?>
                        </div>

                    </div>
                </div>

            </section>


        <?php endif; ?>

        <?php

        do_action('applica_after_video_cta');

        echo $args['after_widget'];

        echo ob_get_clean();
    }

}