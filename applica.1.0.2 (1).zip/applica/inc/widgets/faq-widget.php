<?php
if (!defined('ABSPATH')) {
    exit;
}

class Applica_FAQ_Posts extends Applica_Widget_Base
{
    /**
     * Sets up a new widget instance.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        $icon_page_link = get_site_url() . '/twp-applica-svg-icon-set';
        $this->widget_cssclass = 'widget_applica_faq_posts';
        $this->widget_description = __("Displays faq posts with an image", 'applica');
        $this->widget_id = 'applica_faq_posts';
        $this->widget_name = __('Applica: FAQ Section', 'applica');
        $this->settings = array(
            'title' => array(
                'type' => 'text',
                'label' => __('Title', 'applica'),
            ),
            'description' => array(
                'type' => 'textarea',
                'label' => __('Section Description', 'applica'),
            ),
            'featured_image' => array(
                'type' => 'image',
                'label' => __('Featured Image', 'applica'),
            ),
            'page_id_1' => array(
                'label' => esc_html__('Select Page - 1', 'applica'),
                'type' => 'dropdown-pages',
                'std' => '',
            ),
            'page_id_2' => array(
                'label' => esc_html__('Select Page - 2', 'applica'),
                'type' => 'dropdown-pages',
            ),
            'page_id_3' => array(
                'label' => esc_html__('Select Page - 3', 'applica'),
                'type' => 'dropdown-pages',
            ),
            'page_id_4' => array(
                'label' => esc_html__('Select Page - 4', 'applica'),
                'type' => 'dropdown-pages',
            ),
            'page_id_5' => array(
                'label' => esc_html__('Select Page - 5', 'applica'),
                'type' => 'dropdown-pages',
            ),

        );
        parent::__construct();
    }

    /**
     * Query the posts and return them.
     * @param array $args
     * @param array $instance
     * @return WP_Query
     */
    public function get_posts($args, $instance)
    {
        $applica_faq_page = array();
        for ($i = 1; $i <= 5; $i++) {
            $applica_faq_page_list[] = absint($instance['page_id_' . $i]);
        }
        $query_args = array(
            'posts_per_page' => 5,
            'orderby' => 'post__in',
            'post_type' => 'page',
            'post__in' => $applica_faq_page_list,
        );

        return new WP_Query(apply_filters('applica_faq_posts_query_args', $query_args));
    }

    /**
     * Output widget.
     *
     * @param array $args
     * @param array $instance
     * @see WP_Widget
     *
     */
    public function widget($args, $instance)
    {
        ob_start();
        if (($posts = $this->get_posts($args, $instance)) && $posts->have_posts()) {
            $i = 1;
            ?>

            <div class="theme-workflow theme-block">
                <div class="wrapper">
                    <div class="column-row">
                        <div class="column column-6 column-sm-12 sm-mb-16">
                            <h2 class="entry-title font-size-big">
                                <?php echo esc_html($instance['title']); ?>
                            </h2>
                            <p>
                                <?php echo esc_html($instance['description']); ?>
                            </p>
                            <div class="workflow-detail-container">
                                <?php while ($posts->have_posts()):
                                    $posts->the_post(); ?>
                                    <div class="workflow-detail-item">
                                        <span>
                                            <?php echo $i; ?>
                                        </span>
                                        <div class="theme-workflow-detail">
                                            <div class="workflow-detail-header">
                                                <h2 class="entry-title font-size-medium line-clamp line-clamp-2">
                                                    <?php the_title(); ?>
                                                </h2>

                                                <?php applica_theme_svg('chevron-down'); ?>
                                            </div>

                                            <div class="workflow-detail-body">
                                                <?php the_excerpt(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php $i++;
                                endwhile;
                                wp_reset_postdata(); ?>
                            </div>
                        </div>

                        <div class="column column-6 column-sm-12">
                            <div class="theme-applica-image image-size-large">
                                <img src="<?php echo esc_url(wp_get_attachment_image_url($instance['featured_image'], 'medium-large')); ?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
        }
        echo ob_get_clean();
    }
}