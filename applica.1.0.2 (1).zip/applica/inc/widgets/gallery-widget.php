<?php
if (!defined('ABSPATH')) {
    exit;
}

class Applica_Gallery_Widget extends Applica_Widget_Base
{
    /**
     * Sets up a new widget instance.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        $this->widget_cssclass = 'widget_applica_gallery_posts';
        $this->widget_description = __("Displays gallery section with an image", 'applica');
        $this->widget_id = 'applica_gallery_posts';
        $this->widget_name = __('Applica: Gallery Section', 'applica');
        $this->settings = array(
            'title' => array(
                'type' => 'text',
                'label' => __('Title', 'applica'),
            ),
            'description' => array(
                'type' => 'textarea',
                'label' => __('Section Description', 'applica'),
            ),
            'gallery_image_1'  => array(
                'type'  => 'image',
                'label' => __('Gallery Image - 1', 'applica'),
            ),
            'gallery_image_2'  => array(
                'type'  => 'image',
                'label' => __('Gallery Image - 2', 'applica'),
            ),
            'gallery_image_3'  => array(
                'type'  => 'image',
                'label' => __('Gallery Image - 3', 'applica'),
            ),
            'gallery_image_4'  => array(
                'type'  => 'image',
                'label' => __('Gallery Image - 4', 'applica'),
            ),
            'gallery_image_5'  => array(
                'type'  => 'image',
                'label' => __('Gallery Image - 5', 'applica'),
            ),
            'gallery_image_6'  => array(
                'type'  => 'image',
                'label' => __('Gallery Image - 6', 'applica'),
            ),

        );
        parent::__construct();
    }

    /**
     * Output widget.
     *
     * @param array $args
     * @param array $instance
     * @see WP_Widget
     *
     */
    public function widget($args, $instance)
    {
        ob_start();
            ?>
            <section class="theme-screenshot-carousel theme-block">
                <div class="wrapper">
                    <div class="column-row">
                        <div class="column column-12">
                            <div class="theme-section-header text-center mb-56">
                                <h2>
                                    <?php echo esc_html($instance['title']); ?>
                                </h2>

                                <p class='m-0'>
                                    <?php echo esc_html($instance['description']); ?> 
                                </p>
                            </div>

                            <div class="theme-section-body relative">
                                <div class="screenshot-carouse-wrapper swiper">
                                    <div class="swiper-wrapper">
                                        <?php for ($i= 1; $i <=6 ; $i++) { 
                                            $image_id = $instance['gallery_image_'.$i];
                                            if (!empty($image_id)) {
                                            ?>
                                            <div class="swiper-slide">
                                                <div class="data-bg image-size-big"
                                                    data-background='<?php echo esc_url(wp_get_attachment_image_url( $image_id, 'medium-large' )); ?>'>
                                                </div>
                                            </div>
                                            
                                        <?php } } ?>


                                    </div>
                                </div>

                                <div class="screenshot-overlay-phone">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php
        echo ob_get_clean();
    }
}