<?php

/* Theme Widget sidebars. */
require get_template_directory() . '/inc/widgets/widgets.php';
require get_template_directory() . '/inc/widgets/widget-base/widgetbase.php';

require get_template_directory() . '/inc/widgets/recent-widget.php';
require get_template_directory() . '/inc/widgets/social-widget.php';
require get_template_directory() . '/inc/widgets/author-widget.php';
require get_template_directory() . '/inc/widgets/newsletter-widget.php';
require get_template_directory() . '/inc/widgets/tab-widget.php';
require get_template_directory() . '/inc/widgets/cta-widget.php';
require get_template_directory() . '/inc/widgets/service-widget.php';
require get_template_directory() . '/inc/widgets/faq-widget.php';
require get_template_directory() . '/inc/widgets/video-cta.php';
require get_template_directory() . '/inc/widgets/featured-widget.php';
require get_template_directory() . '/inc/widgets/gallery-widget.php';
require get_template_directory() . '/inc/widgets/counter-widget.php';
require get_template_directory() . '/inc/widgets/about-widget.php';

/* Register site widgets */
if ( ! function_exists( 'applica_widgets' ) ) :
    /**
     * Load widgets.
     *
     * @since 1.0.0
     */
    function applica_widgets() {
        register_widget( 'Applica_Recent_Posts' );
        register_widget( 'Applica_Social_Menu' );
        register_widget( 'Applica_Author_Info' );
        register_widget( 'Applica_Mailchimp_Form' );
        register_widget( 'Applica_Call_To_Action' );
        register_widget( 'Applica_Tab_Posts' );
        register_widget( 'Applica_Service_Posts' );
        register_widget( 'Applica_FAQ_Posts' );
        register_widget( 'Applica_Featured_Widget' );
        register_widget( 'Applica_Gallery_Widget' );
        register_widget( 'Applica_Video_Call_To_Action' );
        register_widget( 'Applica_Counter_Widget' );
        register_widget( 'Applica_About_Widget' );
    }
endif;
add_action( 'widgets_init', 'applica_widgets' );