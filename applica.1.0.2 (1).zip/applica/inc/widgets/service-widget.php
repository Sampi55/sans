<?php
if (!defined('ABSPATH')) {
    exit;
}

class Applica_Service_Posts extends Applica_Widget_Base
{
    /**
     * Sets up a new widget instance.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        $icon_page_link = get_site_url() . '/twp-applica-svg-icon-set';
        $this->widget_cssclass = 'widget_applica_service_posts';
        $this->widget_description = __("Displays service posts with an image", 'applica');
        $this->widget_id = 'applica_service_posts';
        $this->widget_name = __('Applica: Service Section', 'applica');
        $this->settings = array(
            'title' => array(
                'type' => 'text',
                'label' => __('Title', 'applica'),
            ),
            'description' => array(
                'type' => 'textarea',
                'label' => __('Section Description', 'applica'),
            ),
            'bg_image' => array(
                'type' => 'image',
                'label' => __('Background Image', 'applica'),
                'desc' => __('Don\'t upload any image if you do not want to show the background image.', 'applica'),
            ),
            'service_icon_1' => array(
                'type' => 'text',
                'label' => __('Service Icon - 1', 'applica'),
                'desc' => sprintf(__('For SVG Icon  <a href="%s" target="_blank">Click Here</a> to see inbuild icon set', 'applica'), $icon_page_link),
            ),
            'page_id_1' => array(
                'label' => esc_html__('Select Page - 1', 'applica'),
                'type'  => 'dropdown-pages',
                'std'   => '',
            ),
            'service_icon_2' => array(
                'type' => 'text',
                'label' => __('Service Icon - 2', 'applica'),
                'desc' => sprintf(__('For SVG Icon  <a href="%s" target="_blank">Click Here</a> to see inbuild icon set', 'applica'), $icon_page_link),
            ),
            'page_id_2' => array(
                'label' => esc_html__('Select Page - 2', 'applica'),
                'type'  => 'dropdown-pages',
            ),
            'service_icon_3' => array(
                'type' => 'text',
                'label' => __('Service Icon - 3', 'applica'),
                'desc' => sprintf(__('For SVG Icon  <a href="%s" target="_blank">Click Here</a> to see inbuild icon set', 'applica'), $icon_page_link),
            ),
            'page_id_3' => array(
                'label' => esc_html__('Select Page - 3', 'applica'),
                'type'  => 'dropdown-pages',
            ),
            'service_icon_4' => array(
                'type' => 'text',
                'label' => __('Service Icon - 4', 'applica'),
                'desc' => sprintf(__('For SVG Icon  <a href="%s" target="_blank">Click Here</a> to see inbuild icon set', 'applica'), $icon_page_link),
            ),
            'page_id_4' => array(
                'label' => esc_html__('Select Page - 4', 'applica'),
                'type'  => 'dropdown-pages',
            ),
        );
        parent::__construct();
    }

    /**
     * Query the posts and return them.
     * @param array $args
     * @param array $instance
     * @return WP_Query
     */
    public function get_posts_1($args, $instance)
    {
        for ($i = 1; $i <= 2; $i++) {
            $applica_service_page_list[] = absint($instance['page_id_' . $i]);
        }
        $query_args = array(
            'posts_per_page' => 2,
            'orderby' => 'post__in',
            'post_type' => 'page',
            'post__in' => $applica_service_page_list,
        );

        return new WP_Query(apply_filters('applica_service_posts_query_args', $query_args));
    }
    public function get_posts_2($args, $instance)
    {
        for ($i = 3; $i <= 4; $i++) {
            $applica_service_page_list_2[] = absint($instance['page_id_' . $i]);
        }
        $query_args_2 = array(
            'posts_per_page' => 2,
            'orderby' => 'post__in',
            'post_type' => 'page',
            'post__in' => $applica_service_page_list_2,
        );

        return new WP_Query(apply_filters('applica_service_posts_query_args_2', $query_args_2));
    }

    /**
     * Output widget.
     *
     * @param array $args
     * @param array $instance
     * @see WP_Widget
     *
     */
    public function widget($args, $instance)
    {
        ob_start();
        if (($posts = $this->get_posts_1($args, $instance)) && $posts->have_posts()) {
?>

    <section class="theme-about-app theme-block">
        <div class="wrapper">
            <div class="column-row">
                <div class="column column-12">
                    <div class="theme-section-header text-center mb-56">
                        <h2>
                            <?php echo esc_html($instance['title']); ?>
                        </h2>

                        <p class='m-0'>
                            <?php echo esc_html($instance['description']); ?>
                        </p>
                    </div>

                    <div class="theme-section-body">
                        <div class="column-row column-row-center">
                            <div class="column column-4 column-sm-12 space-y-24 sm-mb-16">
                                <?php 
                                $i = 1;
                                while ($posts->have_posts()) : $posts->the_post(); ?>
                                    <div class="about-app-item">
                                        <div class="about-app-icon bg-color-cultured mb-16">
                                            <?php if (!empty($instance['service_icon_' . $i])) { ?>
                                                <?php applica_theme_svg($instance['service_icon_' . $i]); ?>
                                            <?php } ?>
                                        </div>

                                        <h2 class="font-size-xmedium">
                                           <?php the_title(); ?>
                                        </h2>

                                        <p class="m-0">
                                            <?php the_excerpt(); ?>
                                        </p>
                                    </div>
                                <?php $i++;
                                endwhile;
                                wp_reset_postdata(); ?>
                            </div>

                            <div class="column column-4 column-sm-12 sm-mb-16">
                                <div class="theme-applica-image">
                                    <img src="<?php echo wp_get_attachment_image_url($instance['bg_image'], 'full'); ?>" alt="">
                                </div>
                            </div>
                            <?php $posts = $this->get_posts_2($args, $instance); ?>
                            <div class="column column-4 column-sm-12 text-right space-y-24">
                                <?php while ($posts->have_posts()) : $posts->the_post(); ?>
                                    <div class="about-app-item">
                                        <div class="about-app-icon bg-color-cultured mb-16">
                                            <?php if (!empty($instance['service_icon_' . $i])) { ?>
                                            <?php applica_theme_svg($instance['service_icon_' . $i]); ?>
                                            <?php } ?>
                                        </div>

                                        <h2 class="font-size-xmedium">
                                            <?php the_title(); ?>
                                        </h2>

                                        <p class="m-0">
                                            <?php the_excerpt(); ?>
                                        </p>
                                    </div>
                                <?php $i++;
                                endwhile;
                                wp_reset_postdata();?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php
        }
        echo ob_get_clean();
    }
}
