<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Applica
 */

?>

<?php
$enable_footer_recommended_post_section = applica_get_option('enable_footer_recommended_post_section');
if ($enable_footer_recommended_post_section) {
    get_template_part('template-parts/footer/footer-recommended-post');
}

?>
<?php get_template_part('template-parts/footer/footer-widgets-full'); ?>

<?php do_action('applica_before_footer'); ?>

<?php
$is_sticky_footer = applica_get_option('enable_footer_sticky');
?>

<footer id="colophon" class="site-footer <?php echo ($is_sticky_footer) ? 'site-footer-sticky' : ''; ?> ">
    <div class="wrapper">
        <?php get_template_part('template-parts/footer/footer-widgets'); ?>
        <?php get_template_part('template-parts/footer/footer-info'); ?>
    </div>

    <?php
    $enable_scroll_to_top = applica_get_option('enable_scroll_to_top');
    if ($enable_scroll_to_top) {
        ?>
        <a id="theme-scroll-to-start" href="javascript:void(0)">
            <span class="screen-reader-text">
                <?php _e('Scroll to top', 'applica'); ?>
            </span>
            <?php applica_theme_svg('arrow-up'); ?>
        </a>
        <?php
    }
    ?>

    <!-- Custom cursor -->
    <div class="cursor-dot-outline"></div>
    <div class="cursor-dot"></div>
    <!-- .Custom cursor -->

</footer><!-- #colophon -->

<?php do_action('applica_after_footer'); ?>

</div><!-- #page -->

<?php do_action('applica_after_site'); ?>

<?php wp_footer(); ?>

</body>

</html>